﻿
# 说明 

该目录只是作为动态视图参考，由NodeJS端的laytpl提供模板引擎 （https://www.npmjs.com/package/laytpl），在实际使用时，你可以采用html目录下的模版，它经过了详细的整理！
